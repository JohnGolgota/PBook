> Please check all tasks that you've completed by placing an `x` within the square braces below.

## Proposed Changes
- [ ] I've read the [CODE OF CONDUCT](https://github.com/my-first-pr/hacktoberfest-2018/blob/master/CODE_OF_CONDUCT.md) and abide to it.
- [ ] I've read the [CONTRIBUTING.md](https://github.com/my-first-pr/hacktoberfest-2018/blob/master/CONTRIBUTING.md)
- [ ] I've forked the repository.
- [ ] I've created a branch and made my changes in it.
- [ ] I understand opening a PULL REQUEST doesn't mean it will be merged for sure.

## Fixes issue
Fixes #<!--Issue Number-->
