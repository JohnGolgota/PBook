<?php
class tbl_libors{
    protected $id_li;
    protected $titulo_li;
    protected $tituloor_li;
    protected $fpublic_li;
    protected $orderse_li;
    protected $npag_li;
    protected $estado_li;
    protected $com_li;
    protected $fcom_li;
    protected $id_ed;
}
?>